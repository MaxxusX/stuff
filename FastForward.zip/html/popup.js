brws.runtime.sendMessage({type: "open-tab", url: brws.runtime.getURL("/html/options.html")})
window.close()
